# Frontend – Demo UI

Very small vanilla JS page to exercise the backend APIs without needing Postman.

## Usage

1. Open `frontend/index.html` directly in your browser, or serve it with a static server.

2. Set the **API base URL** field to your backend instance, for example:

   ```
   http://localhost:4000/api/v1
   ```

3. Register and log in from the left column, then create/list/update tasks from the right column.

The JWT is stored in `localStorage` under `bajarangs_token` and automatically attached to requests.
