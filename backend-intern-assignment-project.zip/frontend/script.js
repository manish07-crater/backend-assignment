const $ = (id) => document.getElementById(id);

const storageKey = "bajarangs_token";

const showToast = (message) => {
  const toast = $("toast");
  toast.textContent = message;
  toast.style.display = "block";
  setTimeout(() => {
    toast.style.display = "none";
  }, 2500);
};

const getApiBase = () => $("apiBase").value.replace(/\/$/, "");

const getToken = () => localStorage.getItem(storageKey);
const setToken = (token) => {
  if (token) {
    localStorage.setItem(storageKey, token);
  } else {
    localStorage.removeItem(storageKey);
  }
  renderTokenPreview();
};

const renderTokenPreview = () => {
  const token = getToken();
  const el = $("tokenPreview");
  if (!token) {
    el.textContent = "(none)";
    return;
  }
  el.textContent = token.slice(0, 16) + "…";
};

const authHeaders = () => {
  const token = getToken();
  return token
    ? { Authorization: `Bearer ${token}`, "Content-Type": "application/json" }
    : { "Content-Type": "application/json" };
};

const safeFetch = async (path, options = {}) => {
  const res = await fetch(`${getApiBase()}${path}`, options);
  let payload;
  try {
    payload = await res.json();
  } catch (_) {
    payload = null;
  }
  if (!res.ok) {
    const message = (payload && payload.message) || res.statusText || "Request failed";
    throw new Error(message);
  }
  return payload;
};

// Auth handlers
$("btnRegister").addEventListener("click", async () => {
  try {
    const body = {
      name: $("regName").value.trim(),
      email: $("regEmail").value.trim(),
      password: $("regPassword").value,
    };
    const data = await safeFetch("/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    setToken(data.data.token);
    showToast("Registered & logged in");
  } catch (err) {
    console.error(err);
    showToast(err.message);
  }
});

$("btnLogin").addEventListener("click", async () => {
  try {
    const body = {
      email: $("loginEmail").value.trim(),
      password: $("loginPassword").value,
    };
    const data = await safeFetch("/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    setToken(data.data.token);
    showToast("Logged in");
  } catch (err) {
    console.error(err);
    showToast(err.message);
  }
});

$("btnLogout").addEventListener("click", () => {
  setToken(null);
  showToast("Logged out");
});

// Tasks
const renderTasks = (tasks) => {
  const container = $("tasks");
  container.innerHTML = "";
  if (!tasks.length) {
    container.innerHTML = '<p class="muted">No tasks yet.</p>';
    return;
  }
  tasks.forEach((t) => {
    const div = document.createElement("div");
    div.className = "task";
    div.innerHTML = `
      <header>
        <div>
          <strong>${t.title}</strong>
          <div class="muted">#${t.id}</div>
        </div>
        <span class="status-pill">${t.status}</span>
      </header>
      <p class="muted">${t.description || ""}</p>
      <div class="task-actions">
        <button data-id="${t.id}" class="secondary btn-edit">Edit</button>
        <button data-id="${t.id}" class="danger btn-delete">Delete</button>
      </div>
    `;
    container.appendChild(div);
  });

  container.querySelectorAll(".btn-edit").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-id");
      const task = tasks.find((t) => String(t.id) === String(id));
      $("taskId").value = task.id;
      $("taskTitle").value = task.title;
      $("taskDescription").value = task.description;
      $("taskStatus").value = task.status;
    });
  });

  container.querySelectorAll(".btn-delete").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!confirm("Delete this task?")) return;
      try {
        const id = btn.getAttribute("data-id");
        await safeFetch(`/tasks/${id}`, {
          method: "DELETE",
          headers: authHeaders(),
        });
        showToast("Task deleted");
        await refreshTasks();
      } catch (err) {
        console.error(err);
        showToast(err.message);
      }
    });
  });
};

const refreshTasks = async () => {
  try {
    const data = await safeFetch("/tasks", {
      method: "GET",
      headers: authHeaders(),
    });
    renderTasks(data.data.tasks);
  } catch (err) {
    console.error(err);
    showToast(err.message);
  }
};

$("btnSaveTask").addEventListener("click", async () => {
  try {
    const id = $("taskId").value.trim();
    const body = {
      title: $("taskTitle").value.trim(),
      description: $("taskDescription").value.trim(),
    };
    const status = $("taskStatus").value;
    if (status) body.status = status;

    const method = id ? "PUT" : "POST";
    const path = id ? `/tasks/${id}` : "/tasks";

    const data = await safeFetch(path, {
      method,
      headers: authHeaders(),
      body: JSON.stringify(body),
    });

    $("taskId").value = "";
    $("taskTitle").value = "";
    $("taskDescription").value = "";
    $("taskStatus").value = "";

    showToast(id ? "Task updated" : "Task created");
    await refreshTasks();
  } catch (err) {
    console.error(err);
    showToast(err.message);
  }
});

$("btnRefreshTasks").addEventListener("click", refreshTasks);

// Initial state
renderTokenPreview();
if (getToken()) {
  refreshTasks();
}
