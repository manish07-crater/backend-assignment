# Backend Developer (Intern) – Assignment

This repository contains a reference implementation for the assignment:

- Secure auth (registration, login, JWT)
- Role‑based access (user vs admin)
- CRUD APIs for a secondary entity (tasks)
- Basic HTML/JS frontend to interact with the API
- Postman collection
- Short scalability note

## Layout

- `backend/` – Node.js + Express + PostgreSQL API
- `frontend/` – Minimal HTML/JS client
