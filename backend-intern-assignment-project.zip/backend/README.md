# Backend – Bajarangs Assignment

Simple Node.js + Express + PostgreSQL backend for the Backend Developer Intern assignment.

## Tech stack

- Node.js / Express
- PostgreSQL (`pg` driver)
- JWT authentication
- Bcrypt password hashing

## Getting started

1. Install dependencies:

   ```bash
   cd backend
   npm install
   ```

2. Create `.env`:

   ```bash
   cp .env.example .env
   ```

   Adjust DB credentials and `JWT_SECRET` as needed.

3. Create the database and tables in PostgreSQL:

   ```bash
   createdb bajarangs_assignment   # or use pgAdmin
   psql bajarangs_assignment -f sql/schema.sql
   ```

4. Run the API:

   ```bash
   npm run dev
   ```

   The API will be available on `http://localhost:4000` by default.

## API overview

All endpoints are under `/api/v1`.

### Auth

- `POST /api/v1/auth/register` – Register a user
- `POST /api/v1/auth/login` – Login and receive a JWT
- `GET /api/v1/auth/me` – Get current user (requires `Authorization: Bearer <token>`)

### Tasks

All task routes require a valid JWT.

- `POST /api/v1/tasks` – Create a task for the logged‑in user
- `GET /api/v1/tasks` –
  - For normal users: list their own tasks
  - For admins: list all tasks
- `GET /api/v1/tasks/:id` – Get a single task (must own it, unless admin)
- `PUT /api/v1/tasks/:id` – Update a task
- `DELETE /api/v1/tasks/:id` – Delete a task

Status values: `pending`, `in_progress`, `done`.

## API documentation

A Postman collection is included as `postman_collection.json`. You can import it into Postman or Insomnia.
