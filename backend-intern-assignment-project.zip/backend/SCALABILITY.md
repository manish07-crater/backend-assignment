# Scalability & Architecture Notes

This project is deliberately small, but the structure keeps a few things in mind:

- **API versioning**: All routes are mounted under `/api/v1`. Future breaking changes can live under `/api/v2` without disturbing existing clients.
- **Layered structure**: `controllers` are thin and deal with HTTP concerns, while `models` know how to talk to the database. This makes it easier to move towards services/microservices later.
- **Database**: PostgreSQL is a good fit for transactional workloads. For higher scale we can:
  - Add read replicas for heavy read traffic.
  - Use connection pooling (already handled by `pg.Pool`).
  - Introduce caching (Redis) for frequently accessed data, e.g., read‑heavy task lists.
- **Authentication**:
  - JWTs are stateless, which makes horizontal scaling straightforward. Any node that has the `JWT_SECRET` can validate tokens.
  - For stricter control (e.g., force logout), we can add a token blacklist or keep refresh tokens in a store like Redis.
- **Microservices path**:
  - Auth & user management can be split out as a separate service once the domain grows.
  - Tasks / notes / products can live in another service that shares only IDs & claims via JWT.
  - Gateway/API‑gateway (e.g., Nginx, Kong) can route `/auth` and `/tasks` traffic to different services.
- **Observability**:
  - Application‑level logging can be routed to something like ELK/EFK.
  - Basic health checks are already present at `/health`; readiness/liveness probes can be wired for container orchestration (Kubernetes).
- **Deployment**:
  - The app can be containerized with Docker and deployed behind a load balancer.
  - Horizontal scaling is as simple as running more container instances because the app itself is stateless.
