import jwt from "jsonwebtoken";
import { config } from "../config/config.js";
import { AppError } from "./errorHandler.js";
import { findUserById } from "../models/userModel.js";

const auth = async (req, res, next) => {
  try {
    const header = req.headers.authorization;
    if (!header || !header.startsWith("Bearer ")) {
      throw new AppError(401, "Authentication required");
    }

    const token = header.split(" ")[1];
    const decoded = jwt.verify(token, config.jwt.secret);

    const user = await findUserById(decoded.sub);
    if (!user) {
      throw new AppError(401, "User no longer exists");
    }

    req.user = {
      id: user.id,
      email: user.email,
      role: user.role,
      name: user.name,
    };

    next();
  } catch (err) {
    if (err.name === "JsonWebTokenError" || err.name === "TokenExpiredError") {
      return next(new AppError(401, "Invalid or expired token"));
    }
    next(err);
  }
};

const requireRole = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return next(new AppError(403, "You are not allowed to perform this action"));
    }
    next();
  };
};

export { auth, requireRole };
