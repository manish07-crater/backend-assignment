import { query } from "../config/db.js";

const toTask = (row) => ({
  id: row.id,
  userId: row.user_id,
  title: row.title,
  description: row.description,
  status: row.status,
  createdAt: row.created_at,
  updatedAt: row.updated_at,
});

export const createTask = async ({ userId, title, description }) => {
  const result = await query(
    `INSERT INTO tasks (user_id, title, description)
     VALUES ($1, $2, $3)
     RETURNING *`,
    [userId, title, description]
  );
  return toTask(result.rows[0]);
};

export const getTaskById = async (id) => {
  const result = await query("SELECT * FROM tasks WHERE id = $1", [id]);
  return result.rows[0] ? toTask(result.rows[0]) : null;
};

export const getTasksForUser = async (userId) => {
  const result = await query("SELECT * FROM tasks WHERE user_id = $1 ORDER BY created_at DESC", [userId]);
  return result.rows.map(toTask);
};

export const getAllTasks = async () => {
  const result = await query("SELECT * FROM tasks ORDER BY created_at DESC", []);
  return result.rows.map(toTask);
};

export const updateTask = async ({ id, title, description, status }) => {
  const result = await query(
    `UPDATE tasks
     SET title = COALESCE($2, title),
         description = COALESCE($3, description),
         status = COALESCE($4, status),
         updated_at = NOW()
     WHERE id = $1
     RETURNING *`,
    [id, title, description, status]
  );
  return result.rows[0] ? toTask(result.rows[0]) : null;
};

export const deleteTask = async (id) => {
  await query("DELETE FROM tasks WHERE id = $1", [id]);
};
