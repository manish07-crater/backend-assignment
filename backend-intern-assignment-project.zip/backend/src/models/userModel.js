import { query } from "../config/db.js";

const toUser = (row) => ({
  id: row.id,
  name: row.name,
  email: row.email,
  passwordHash: row.password_hash,
  role: row.role,
  createdAt: row.created_at,
  updatedAt: row.updated_at,
});

export const createUser = async ({ name, email, passwordHash, role = "user" }) => {
  const result = await query(
    `INSERT INTO users (name, email, password_hash, role)
     VALUES ($1, $2, $3, $4)
     RETURNING *`,
    [name, email, passwordHash, role]
  );
  return toUser(result.rows[0]);
};

export const findUserByEmail = async (email) => {
  const result = await query("SELECT * FROM users WHERE email = $1", [email]);
  return result.rows[0] ? toUser(result.rows[0]) : null;
};

export const findUserById = async (id) => {
  const result = await query("SELECT * FROM users WHERE id = $1", [id]);
  return result.rows[0] ? toUser(result.rows[0]) : null;
};
