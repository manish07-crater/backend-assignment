import { AppError } from "../middleware/errorHandler.js";
import {
  createTask,
  getTaskById,
  getTasksForUser,
  getAllTasks,
  updateTask,
  deleteTask,
} from "../models/taskModel.js";

export const createTaskHandler = async (req, res, next) => {
  try {
    const { title, description } = req.body;
    if (!title) {
      throw new AppError(400, "title is required");
    }

    const task = await createTask({
      userId: req.user.id,
      title,
      description: description || "",
    });

    res.status(201).json({ status: "success", data: { task } });
  } catch (err) {
    next(err);
  }
};

export const listTasksHandler = async (req, res, next) => {
  try {
    const tasks =
      req.user.role === "admin"
        ? await getAllTasks()
        : await getTasksForUser(req.user.id);

    res.json({ status: "success", data: { tasks } });
  } catch (err) {
    next(err);
  }
};

export const getTaskHandler = async (req, res, next) => {
  try {
    const { id } = req.params;
    const task = await getTaskById(id);
    if (!task) {
      throw new AppError(404, "Task not found");
    }

    if (req.user.role !== "admin" && task.userId !== req.user.id) {
      throw new AppError(403, "You cannot access this task");
    }

    res.json({ status: "success", data: { task } });
  } catch (err) {
    next(err);
  }
};

export const updateTaskHandler = async (req, res, next) => {
  try {
    const { id } = req.params;
    const existing = await getTaskById(id);
    if (!existing) {
      throw new AppError(404, "Task not found");
    }

    if (req.user.role !== "admin" && existing.userId !== req.user.id) {
      throw new AppError(403, "You cannot update this task");
    }

    const { title, description, status } = req.body;

    const allowedStatuses = ["pending", "in_progress", "done"];
    if (status && !allowedStatuses.includes(status)) {
      throw new AppError(400, `status must be one of: ${allowedStatuses.join(", ")}`);
    }

    const task = await updateTask({
      id,
      title,
      description,
      status,
    });

    res.json({ status: "success", data: { task } });
  } catch (err) {
    next(err);
  }
};

export const deleteTaskHandler = async (req, res, next) => {
  try {
    const { id } = req.params;
    const existing = await getTaskById(id);
    if (!existing) {
      throw new AppError(404, "Task not found");
    }

    if (req.user.role !== "admin" && existing.userId !== req.user.id) {
      throw new AppError(403, "You cannot delete this task");
    }

    await deleteTask(id);
    res.status(204).send();
  } catch (err) {
    next(err);
  }
};
