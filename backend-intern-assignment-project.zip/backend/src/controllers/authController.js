import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { AppError } from "../middleware/errorHandler.js";
import { createUser, findUserByEmail } from "../models/userModel.js";
import { config } from "../config/config.js";

const SALT_ROUNDS = 10;

const generateToken = (user) => {
  const payload = { sub: user.id, role: user.role };
  return jwt.sign(payload, config.jwt.secret, { expiresIn: config.jwt.expiresIn });
};

export const register = async (req, res, next) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      throw new AppError(400, "name, email and password are required");
    }

    const existing = await findUserByEmail(email);
    if (existing) {
      throw new AppError(409, "User with this email already exists");
    }

    if (password.length < 6) {
      throw new AppError(400, "Password should be at least 6 characters");
    }

    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
    const user = await createUser({ name, email, passwordHash });

    const token = generateToken(user);

    res.status(201).json({
      status: "success",
      data: {
        user: { id: user.id, name: user.name, email: user.email, role: user.role },
        token,
      },
    });
  } catch (err) {
    next(err);
  }
};

export const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      throw new AppError(400, "email and password are required");
    }

    const user = await findUserByEmail(email);
    if (!user) {
      throw new AppError(401, "Invalid credentials");
    }

    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) {
      throw new AppError(401, "Invalid credentials");
    }

    const token = generateToken(user);

    res.json({
      status: "success",
      data: {
        user: { id: user.id, name: user.name, email: user.email, role: user.role },
        token,
      },
    });
  } catch (err) {
    next(err);
  }
};

export const me = async (req, res) => {
  res.json({
    status: "success",
    data: { user: req.user },
  });
};
