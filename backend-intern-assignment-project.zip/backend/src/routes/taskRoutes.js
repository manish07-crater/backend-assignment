import { Router } from "express";
import {
  createTaskHandler,
  listTasksHandler,
  getTaskHandler,
  updateTaskHandler,
  deleteTaskHandler,
} from "../controllers/taskController.js";

const router = Router();

router.post("/", createTaskHandler);
router.get("/", listTasksHandler);
router.get("/:id", getTaskHandler);
router.put("/:id", updateTaskHandler);
router.delete("/:id", deleteTaskHandler);

export default router;
