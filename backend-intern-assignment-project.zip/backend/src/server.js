import app from "./app.js";
import { config } from "./config/config.js";

const server = app.listen(config.port, () => {
  console.log(`API listening on http://localhost:${config.port}`);
});

process.on("SIGTERM", () => {
  console.log("SIGTERM received, shutting down gracefully");
  server.close(() => {
    process.exit(0);
  });
});
